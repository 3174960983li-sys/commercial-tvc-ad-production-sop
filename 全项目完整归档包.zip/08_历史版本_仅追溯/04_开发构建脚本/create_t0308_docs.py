from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import glob, json
base=Path('/mnt/data/AI商业广告SOP_V1.0_T03-08统一接口整改与V1.1发布')
mods={
'T03-01':['delivery_variant_id与asset_variant_id必须分离；合同范围使用deliverable_spec_id，实际交付文件使用deliverable_id。','项目预算/承诺使用budget_line_id；实际成本仅记录于T03-05 24_成本总账的cost_entry_id。','T03-01 09_变更请求是M02唯一审批主记录；V11_成果注册/M09、V11_权利记录/M08、V11_步骤执行实例为跨项目系统主记录。'],
'T03-02':['正式G1/G2/G3决策仅录入本工作簿V11_Gate记录；15_G1-G3审核保留业务审查意见与证据。','广告宣称claim_id须具备可信证据和授权确认；研究证据状态与权利许可状态分离。','外部权利许可引用T03-01 V11_权利记录中的rights_record_id。'],
'T03-03':['G4联合批准Script Master与Director Bible；G5批准分镜/Animatic；权威记录均在V11_Gate记录。','P6-09的图像Panel登记使用V11_StoryboardPanel，逐Panel登记panel_id、shot_id、image_ref、file_hash、版本和审核证据。','P4-P6 27项正式步骤映射见V11_步骤映射及对应V1.1 JSON。'],
'T03-04':['资产变体使用asset_variant_id，不得与交付变体delivery_variant_id混用。','G6正式审批仅录入V11_Gate记录；资产本身需有版本、来源、许可记录和镜头映射。','source_mode统一为AI/LIVE/CG/HYBRID；“POST_ONLY”属于工艺标签而非统一素材来源。'],
'T03-05':['真实费用唯一总账为24_成本总账cost_entry_id；返工成本是ACTUAL成本子集，不得重复累计。','正式G7a/G7b各自独立审批，记录在V11_Gate记录；旧表仅保存QA和业务证据。','媒体QA的根状态使用V11_媒体QA状态；媒体候选生产状态与商业审批状态分开。','失败attempt可以无take；只对确有有效媒体的take登记文件路径、hash和元数据。'],
'T03-06':['G8逐实际交付变体+文件Hash+市场+平台+权利范围审批；G8通过不等于送达或客户验收。','13_P10交付验收为delivery_status主记录；02变体准备度与28派生状态不得成为第二主状态源。','P11启动与投放数据可用性分离；未启动P11应记P11_NOT_ACTIVATED/G9_NOT_APPLICABLE，不得写G9 PASS。','原始投放报告登记source_report_id；M02本地变更仅引用T03-01主记录。']}

norm='Gate统一decision=PASS/CONDITIONAL/REWORK/HOLD；approval_mode独立记录REAL_APPROVAL/SIMULATED_APPROVAL。必须保留gate_id、scope_ids、reviewed_artifact_ids、reviewed_versions、reviewed_hashes、decision、findings、required_actions、owner、approver、approval_evidence、reviewed_at、validity_conditions。'
for tag,notes in mods.items():
    src=Path(glob.glob(f'/mnt/data/AI商业广告SOP_V1.0_{tag}*')[0]); target=base/tag; target.mkdir(exist_ok=True)
    for fp in src.glob('*.docx'):
        doc=Document(fp)
        if doc.paragraphs:
            pre=doc.paragraphs[0].insert_paragraph_before('【V1.1接口修订】本文原有业务表格继续可用；涉及Gate审批、ID、状态、成本、权利、变更时，以V1.1 Excel/JSON和本文件末尾附录为准。')
            pre.paragraph_format.space_after=Pt(8)
            rr=pre.runs[0]; rr.bold=True; rr.font.name='Microsoft YaHei'; rr.font.size=Pt(8); rr.font.color.rgb=RGBColor(26,76,105)
        doc.add_page_break()
        doc.add_heading('V1.1｜统一接口与兼容性附录', level=1)
        doc.add_paragraph('适用基线：Architecture Baseline V1.0；第二阶段S07跨阶段统一规则 V1.0；第三阶段T01执行架构。原业务内容未作为本次接口整改的重写对象。')
        doc.add_heading('一、权威Gate与审查边界',level=2)
        doc.add_paragraph(norm)
        doc.add_paragraph('原有业务审核表只承担业务事实、QA、审查意见及证据采集；实际Gate决定由本模块V11_Gate记录统一出具。AI或内部模拟审批不得冒充广告主、法务或品牌权利人的真实授权。')
        doc.add_heading('二、本模块V1.1变更',level=2)
        for note in notes:doc.add_paragraph(note,style='List Bullet')
        doc.add_heading('三、使用与记录责任',level=2)
        doc.add_paragraph('填写顺序：先确认project_id及已锁定上游版本；填写业务原表与证据；在V11_步骤映射定位正式步骤；将需正式审批的成果登记到本模块V11_Gate记录；出现变更时引用T03-01 09_变更请求的唯一change_request_id。')
        doc.add_paragraph('版本和状态：保留已锁定旧版；新文件新版本新Hash需要重新判定受影响Gate。不满足必需授权、事实、权利或法律条件时，必须HOLD或REWORK，不能将未核实写成PASS。')
        doc.add_paragraph('说明：本次仅通过静态结构与字段检查。具体模型能力、实际片段质量、法律与平台规格、客户签批、真实投放和商业效果均未在此证明。')
        dst=target/(fp.stem+'_V1.1.docx')
        doc.save(dst)
    # concise module guide
    d=Document()
    sec=d.sections[0]; sec.top_margin=Inches(.68);sec.bottom_margin=Inches(.68)
    d.add_heading(f'{tag}｜V1.1 执行与接口迁移指南',0)
    d.add_paragraph('版本：1.1.0｜2026-11-03｜依照S07 V1.0｜适用于个人与小团队（AI优先、允许混合制作）')
    d.add_heading('模块整改重点',1)
    for note in notes:d.add_paragraph(note,style='List Bullet')
    d.add_heading('统一Gate格式',1)
    d.add_paragraph(norm)
    d.add_heading('V1.1文件定位',1)
    d.add_paragraph('业务工作簿：原有业务表+V11_Gate记录+V11_步骤映射+V11_字段权威目录+V11_外键交接及该模块必要新增登记。')
    d.add_paragraph('机器接口：V1.1 JSON是该版本字段/枚举/步骤/权威来源的校验标准，不能被旧版Word字段覆盖。')
    d.add_paragraph('业务文档：本模块各Word模板加入“V1.1统一接口与兼容性附录”。如正文遗留旧状态名称，应按最新附录和JSON解释。')
    d.add_heading('交付与适用性限制',1)
    d.add_paragraph('本次更新不涉及真实业务数据导入或客户签批。历史已填V1.0数据应先备份，再按字段映射人工核实迁移；不可仅批量替换文本就视为完成审查。')
    d.save(target/f'{tag}_V1.1_执行与兼容指南.docx')
    print(tag,'word',len(list(target.glob('*.docx'))))
