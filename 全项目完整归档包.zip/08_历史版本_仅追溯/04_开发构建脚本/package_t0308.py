import json,zipfile,hashlib
from pathlib import Path
base=Path('/mnt/data/AI商业广告SOP_V1.0_T03-08统一接口整改与V1.1发布')
root=Path('/mnt/data')
index={"release":"T03-08","version":"V1.1.0","date":"2026-11-03","baseline":"S07 V1.0","review":"STATIC PASS; dynamic T03-09 NOT_TESTED","module_packs":[]}
for i in range(1,7):
 tag=f'T03-{i:02d}';folder=base/tag
 items=sorted(p for p in folder.iterdir() if p.is_file() and not p.name.endswith('_SHA256清单.json'))
 manifest={"module":tag,"version":"V1.1.0","files":[{"name":p.name,"size":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in items]}
 manifest_path=folder/f'{tag}_V1.1_SHA256清单.json'
 manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
 zpath=root/f'AI商业广告SOP_V1.0_{tag}_V1.1统一接口修订模板包.zip'
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in items+[manifest_path]:z.write(p,arcname=p.name)
 with zipfile.ZipFile(zpath) as z:
  assert z.testzip() is None
  for f in manifest['files']:
   assert hashlib.sha256(z.read(f['name'])).hexdigest()==f['sha256']
 index['module_packs'].append({"module":tag,"file":zpath.name,"files":len(items)+1,"bytes":zpath.stat().st_size})
files=sorted(p for p in base.iterdir() if p.is_file() and p.name!='T03-08_总清单与SHA256.json')
for mod in sorted(base.glob('T03-??')):
 files.extend(sorted(p for p in mod.iterdir() if p.is_file()))
fullmanifest={"release":"T03-08","version":"V1.1.0","files":[{"relative_path":str(p.relative_to(base)),"size":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],"module_packs":index['module_packs']}
fm=base/'T03-08_总清单与SHA256.json';fm.write_text(json.dumps(fullmanifest,ensure_ascii=False,indent=2),encoding='utf-8')
master=root/'AI商业广告全流程制作SOP_V1.0_T03-08_六大模板V1.1统一接口整改全套.zip'
with zipfile.ZipFile(master,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files+[fm]: z.write(p,arcname=str(p.relative_to(base)))
with zipfile.ZipFile(master) as z:
 assert z.testzip() is None
 for e in fullmanifest['files']:
  assert hashlib.sha256(z.read(e['relative_path'])).hexdigest()==e['sha256']
assert len([x for x in fullmanifest['files'] if x['relative_path'].endswith('.xlsx')])==7
assert len([x for x in fullmanifest['files'] if x['relative_path'].endswith('.docx')])==35
print('FINAL_FULL_ZIP',master.name,master.stat().st_size,'bytes')
print('MODULE_COUNTS',[(m['module'],m['files'],m['bytes']) for m in index['module_packs']])
print('FULL_FILES',len(files)+1,'DOCX',35,'XLSX',7,'JSON',len([p for p in files if p.suffix=='.json']))
print('SHA256_VERIFICATION_ALL_PASS')
