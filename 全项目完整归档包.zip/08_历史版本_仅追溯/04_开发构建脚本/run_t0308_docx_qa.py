import subprocess,time,os,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
base=Path('/mnt/data/AI商业广告SOP_V1.0_T03-08统一接口整改与V1.1发布')
qabase=Path('/mnt/data/t0308_qapreview')
files=sorted(base.glob('T03-*/*.docx'))
print('DOCX_RENDER_COUNT',len(files),flush=True)
def render_docx(p):
    target=qabase/p.parent.name/p.stem
    target.mkdir(parents=True,exist_ok=True)
    cmd=['python','/home/oai/skills/docx/render_docx.py',str(p),'--output_dir',str(target)]
    t=time.time()
    try:
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
        n=len(list(target.glob('page-*.png')))
        return {'file':p.name,'module':p.parent.name,'pages':n,'returncode':r.returncode,'seconds':round(time.time()-t,1),'error':(r.stderr[-200:] if r.returncode else '')}
    except Exception as e:
        return {'file':p.name,'module':p.parent.name,'pages':0,'returncode':-1,'seconds':round(time.time()-t,1),'error':str(e)}
results=[]
with ThreadPoolExecutor(max_workers=3) as exe:
    fut={exe.submit(render_docx,p):p for p in files}
    for f in as_completed(fut):
        v=f.result();results.append(v)
        print(v['module'],v['file'][:26],v['pages'],v['returncode'],v['seconds'],'sec',flush=True)
(qabase/'render_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print('SUMMARY',len(results),'fail',len([x for x in results if x['returncode']!=0 or not x['pages']]),'pages',sum(x['pages'] for x in results),flush=True)
