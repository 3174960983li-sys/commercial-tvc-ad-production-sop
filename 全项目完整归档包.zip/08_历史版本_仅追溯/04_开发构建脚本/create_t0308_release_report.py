import json
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
base=Path('/mnt/data/AI商业广告SOP_V1.0_T03-08统一接口整改与V1.1发布')
r=json.loads((base/'T03-08_18项整改报告.json').read_text(encoding='utf-8'))
t=json.loads((base/'T03-08_20项静态回归测试结果.json').read_text(encoding='utf-8'))
md=[
'# T03-08｜六大模板统一接口整改与V1.1发布报告','',
'**项目：** AI商业广告全流程制作SOP V1.0  ','**发布版本：** T03-01至T03-06模板V1.1.0  ',
'**日期：** 2026-11-03  ','**状态：** 静态接口发布，通过20/20项结构测试；真实项目端到端试跑未执行。','',
'## 一、结果与约束','',
'- 以第一阶段Architecture Baseline V1.0与第二阶段S07跨阶段统一规则V1.0为最高项目标准；不更改12阶段、99步骤、10主Gate及G7a/G7b。',
'- 六套V1.1 Excel工作簿均保留原有业务工作表，并新增权威Gate记录、步骤路由、唯一主记录和模块专用资产/来源索引。',
'- 34份V1.1 Word已渲染成功，共90页；六份JSON采用统一1.1接口规范。',
'- 18项T03-07发现已实施静态修订，其中5项保留旧版字段/日志的兼容数据迁移要求。',
'- 客户授权、广告法/平台实时合规、AI实际生成能力、费用、成片质量与真实投放结果尚未检验。','',
'## 二、18项整改明细','',
'| ID | 严重度 | 静态修订 | 状态 |','|---|---|---|---|'
]
for f in r['findings']:
    md.append(f"| {f['finding_id']} | {f['severity']} | {f['remediation']} | {f['status']} |")
md.extend(['','## 三、唯一主数据源','',
'- Gate：各业务模块的`V11_Gate记录`；原Gate工作表只保留业务审核材料。',
'- M02变更：T03-01 `09_变更请求`；其他模块仅引用CR及其影响。',
'- M06实际成本：T03-05 `24_成本总账` 的`cost_entry_id`；T03-01保留预算/承诺，T03-06引用复盘。',
'- M08权利：T03-01 `V11_权利记录` 的`rights_record_id`。',
'- M09正式成果：T03-01 `V11_成果注册`。',
'- 步骤实例：T03-01 `V11_步骤执行实例`。',
'- P6-09：T03-03 `V11_StoryboardPanel`。',
'- P11源报告：T03-06 `V11_投放源报告`。','',
'## 四、Gate与状态规范','',
'每个Gate决定必须包含：`gate_id,scope_ids,reviewed_artifact_ids,reviewed_versions,reviewed_hashes,decision,findings,required_actions,owner,approver,approval_evidence,reviewed_at,validity_conditions`，并单独拥有`gate_record_id`。',
'正式`decision`只能取`PASS / CONDITIONAL / REWORK / HOLD`；`SIMULATED_APPROVAL`属于独立`approval_mode`，不得冒充真实客户批准。',
'G8必须匹配交付变体、master_candidate_ref、最终file_hash、market、platform、rights_scope。`G8 PASS`不自动意味着`DELIVERED`或`CLIENT_ACCEPTED`。',
'P11若未启动，必须`P11_NOT_ACTIVATED`与`G9_NOT_APPLICABLE`；不得假称已完成传播效果复盘。','',
'## 五、20项静态回归测试','',
'静态结果：**20/20 PASS_STATIC**；检查范围包括工作簿/表格元数据完整性、99步骤映射、Gate字段、ID拆分、预算实际成本、变更与权利权威来源、状态分离与机器JSON一致性。',
'**不包括：** 客户/品牌真实授权、视频资产存在与可播放、真实模型操作、业务数据外键完整性、各平台实时合规、交付文件真实hash审批与广告效果。','',
'## 六、T03-09后续验收路径','',
'1. 建立明确标记为模拟的30秒广告Brief与产品事实/权利凭证；禁止伪造真实广告主授权。',
'2. 走完P0—P10全部适用流程，保留G0—G8审批证据，按镜头记录G7a/G7b。',
'3. 至少制作两个交付变体，验证9:16/16:9的variant_segment_id和G8逐文件Hash批准。',
'4. 加入一次未通过审核的反向案例，验证HOLD/REWORK与M02回退。',
'5. 分别测试P11未启用、已启用但无投放数据、已启用有真实授权数据三类分支。',
'6. 验证制作成本仅单笔入账，返工成本为子集；检查客户端签收/验收事实分离。',
'7. 最终发布V1.1生产试跑报告，必要时形成V1.2变更请求，而不是覆盖已冻结基线。','',
'## 七、使用兼容说明','',
'每个V1.1包内的Word模板在末尾增加V1.1附录，但为保护原有填写结构，正文部分历史状态术语仍可能出现。冲突时优先遵循S07及V1.1 JSON、权威V11工作表。对于已经填写真实数据的V1.0项目，必须先备份再人工按证据迁移，不能自动把旧`CLEARED`当成已核实权利。'
])
(base/'T03-08_正式发布与整改说明.md').write_text('\n'.join(md),encoding='utf-8')

D=Document();sec=D.sections[0];sec.top_margin=Inches(.63);sec.bottom_margin=Inches(.63);sec.left_margin=Inches(.67);sec.right_margin=Inches(.67)
styles=D.styles
for style in ['Normal','Title','Heading 1','Heading 2']:
 s=styles[style];s.font.name='Microsoft YaHei';s._element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft YaHei')
styles['Normal'].font.size=Pt(8.5);styles['Normal'].paragraph_format.space_after=Pt(3)
for s in ['Heading 1','Heading 2']:
 styles[s].font.color.rgb=RGBColor(32,54,79)
D.add_heading('T03-08｜六大模板统一接口整改与V1.1发布',0)
D.add_paragraph('AI商业广告全流程制作 SOP V1.0｜2026-11-03｜静态接口整改报告')
D.add_heading('一、发布结论',1)
D.add_paragraph('六套业务模板已发布V1.1结构修订；以S07跨阶段统一规则V1.0为对照，20项静态回归测试全部通过，34份Word已渲染成功。此结果不等于真实广告项目、客户批准、平台合规或实际投放效果验收。')
D.add_heading('二、六大模块',1)
for tag,descr in [('T03-01','项目Brief/立项；变更、权利、成果、步骤执行主记录'),('T03-02','品牌与产品事实、策略/创意；G1-G3'),('T03-03','脚本/导演/分镜/Animatic；P6-09分镜Panel；G4-G5'),('T03-04','产品/人物/场景/道具资产；asset_variant_id与G6'),('T03-05','AI/混合生产、Take/Attempt、媒体QA、M06成本与G7a/G7b'),('T03-06','G8逐变体商业审核、交付验收、P11报告与G9')]:
 D.add_paragraph(f'{tag}：{descr}',style='List Bullet')
D.add_heading('三、18项问题整改',1)
T=D.add_table(rows=1,cols=4);T.style='Table Grid';T.alignment=WD_TABLE_ALIGNMENT.CENTER
for c,v in zip(T.rows[0].cells,['ID','严重度','整改摘要','状态']):
 c.text=v
 for run in c.paragraphs[0].runs:run.bold=True;run.font.size=Pt(7)
for f in r['findings']:
 row=T.add_row()
 for c,v in zip(row.cells,[f['finding_id'],f['severity'],f['remediation'],f['status']]):
  c.text=v
  for p in c.paragraphs:
   for run in p.runs:run.font.size=Pt(7)
D.add_heading('四、统一接口主源',1)
for v in ['Gate：每个业务模块V11_Gate记录是唯一权威批准记录；旧Gate仅是业务审查与证据。',
'M02变更：T03-01 09_变更请求；M06实际成本：T03-05 24_成本总账；M08权利：T03-01 V11_权利记录。',
'M09正式成果：T03-01 V11_成果注册；步骤执行：V11_步骤执行实例；P6-09：T03-03 V11_StoryboardPanel。',
'G8逐最终文件：variant+hash+market+platform+rights_scope；交付、签收与客户验收分离。']:
 D.add_paragraph(v,style='List Bullet')
D.add_heading('五、验收边界与下一阶段',1)
D.add_paragraph('20/20通过的是空模板结构、元数据和字段一致性检查，不是带真实业务数据的执行测试。旧字段在V1.1作为兼容接口保留，历史已填数据必须备份并核实迁移。')
D.add_paragraph('下一阶段T03-09：选择合法模拟Brief或有授权真实品牌，跑通P0-P10、两种交付变体与G8逐Hash审批；分支验证P11未启动/无数据/有数据，并执行至少一个REWORK/HOLD回退案例。')
D.save(base/'T03-08_六大模板V1.1正式整改报告.docx')
print('Report ready')
